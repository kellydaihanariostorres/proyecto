import{BrowserRouter, Routes, Route } from "react-router-dom";
import Nav from './Components/Nav';
import Bodegas from './Views/Bodegas/Index';
import CreateBodegas from './Views/Bodegas/Create';
import EditBodegas from './Views/Bodegas/Edit';
import Graphinc from './Views/Empleados/Graphic';
import Empleados from './Views/Empleados/Index';
import Login from './Views/Login';
import Register from './Views/Register';
import ProtectdRoutes from './Components/ProtectdRouted';

function App() {
  return (
    <BrowserRouter>
    <Nav/>
      <Routes>
        <Route path="/login" element={<Login/>}/>
        <Route path="/register" element={<Register/>}/>
        <Route path="/" element={<Bodegas />}/>
        <Route path="/create" element={<CreateBodegas />}/>
        <Route path="/edit/:id" element={<EditBodegas />}/>
        <Route path="/empleados" element={<Empleados />}/>
        <Route path="/graphic" element={<Graphinc />}/>
      </Routes>
    

    </BrowserRouter>
    
  )
}

export default App
