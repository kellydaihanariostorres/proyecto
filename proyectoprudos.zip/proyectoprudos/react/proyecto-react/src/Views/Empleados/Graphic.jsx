import React from 'react'

const Graphic = () => {
  return (
    <div>Graphic</div>
  )
}

export default Graphic