import React from 'react'

const ProtectdRouted = () => {
  return (
    <div>ProtectdRouted</div>
  )
}

export default ProtectdRouted