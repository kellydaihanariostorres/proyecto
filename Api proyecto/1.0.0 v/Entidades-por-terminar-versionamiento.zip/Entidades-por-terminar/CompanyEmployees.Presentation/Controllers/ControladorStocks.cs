﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Service.Contracts;

namespace BodegasEmpleados.Presentacion.Controllers
{
    [ApiController]
    [Route("api/stocks")]
    public class ControladorStocks : ControllerBase
    {
        private readonly IServiceManager _service;

        public ControladorStocks(IServiceManager service) =>
            _service = service;

        [HttpGet]
        public IActionResult GetallStocks()
        {
            //throw new Exception("Exception");
            var stocks = _service.ServicioStock.GetAllStocks(trackChanges: false);
            return Ok(stocks);


        }
        [HttpGet("{stockId:guid}")]
        public IActionResult GetStock(Guid StockId)
        {
            var stock = _service.ServicioStock.GetStock(StockId, trackChanges: false);
            return Ok(stock);
        }
    }
}

