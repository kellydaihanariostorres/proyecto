﻿using Microsoft.AspNetCore.Mvc;
using Service.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompanyEmployees.Presentation.Controllers
{
    [ApiController]
    [Route("api/detalles")]
    public class ControladorDetalles : ControllerBase
    {
        private readonly IServiceManager _service;

        public ControladorDetalles(IServiceManager service) =>
            _service = service;

        [HttpGet]
        public IActionResult GetDetalles()
        {
            //throw new Exception("Exception");
            var detalles =
            _service.ServicioDetalles.GetAllDetalles(trackChanges: false);
            return Ok(detalles);

        }

        [HttpGet("{detalleId:guid}")]
        public IActionResult GetDetalle(Guid detalleId)
        {
            var detalle = _service.ServicioDetalles.GetDetalle(detalleId, trackChanges: false);
            return Ok(detalle);
        }
    }
}
