﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Service.Contracts;

namespace CompanyEmployees.Presentation.Controllers
{
    [ApiController]
    [Route("api/pagoproveedor")]
    public class ControladorPagoProveedor : ControllerBase
    {
        private readonly IServiceManager _service;

        public ControladorPagoProveedor(IServiceManager service) =>
            _service = service;

        [HttpGet]
        public IActionResult GetAllPagoProveedores()
        {
            //throw new Exception("Exception");
            var pagoProveedor = _service.ServicioPagoProveedor.GetAllPagoProveedores(trackChanges: false);
            return Ok(pagoProveedor);


        }
        [HttpGet("{PagoProveedoresId:guid}")]
        public IActionResult GetPagoProveedor(Guid pagoProveedoresId)
        {
            var pagoProveedor = _service.ServicioPagoProveedor.GetPagoProveedor(pagoProveedoresId, trackChanges: false);
            return Ok(pagoProveedor);
        }
    }
}
