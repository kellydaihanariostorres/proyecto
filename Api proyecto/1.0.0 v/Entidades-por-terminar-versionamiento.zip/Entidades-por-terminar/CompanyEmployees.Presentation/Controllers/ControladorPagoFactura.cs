﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Service.Contracts;

namespace BodegasEmpleados.Presentacion.Controllers
{
    [ApiController]
    [Route("api/PagoFacturas")]
    public class ControladorPagoFacturas : ControllerBase
    {
        private readonly IServiceManager _service;

        public ControladorPagoFacturas(IServiceManager service) =>
            _service = service;

        [HttpGet]
        public IActionResult GetallPagoFacturas()
        {
            //throw new Exception("Exception");
            var pagoFacturas = _service.ServicioPagoFactura.GetAllPagoFacturas(trackChanges: false);
            return Ok(pagoFacturas);


        }
        [HttpGet("{PagoFacturaId:guid}")]
        public IActionResult GetPagoFacturas(Guid PagoFacturaId)
        {
            var pagoFacturas = _service.ServicioPagoFactura.GetPagoFactura(PagoFacturaId, trackChanges: false);
            return Ok(pagoFacturas);
        }
    }
}
