﻿using Microsoft.AspNetCore.Mvc;
using Service.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompanyEmployees.Presentation.Controllers
{
    [ApiController]
    [Route("api/estante")]
    public class ControladorEstante : ControllerBase
    {
        private readonly IServiceManager _service;

        public ControladorEstante(IServiceManager service) =>
            _service = service;

        [HttpGet]
        public IActionResult GetEstantes()
        {
            //throw new Exception("Exception");
            var estantes =
            _service.ServicioEstante.GetAllEstante(trackChanges: false);
            return Ok(estantes);

        }

        [HttpGet("{EstantesId:guid}")]
        public IActionResult GetEstante(Guid estantesId)
        {
            var estante = _service.ServicioEstante.GetEstante(estantesId, trackChanges: false);
            return Ok(estante);
        }
    }
}