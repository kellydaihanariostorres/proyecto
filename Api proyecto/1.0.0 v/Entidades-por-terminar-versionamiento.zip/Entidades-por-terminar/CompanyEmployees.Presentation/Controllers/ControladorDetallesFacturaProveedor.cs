﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Service.Contracts;

namespace BodegasEmpleados.Presentacion.Controllers
{
    [ApiController]
    [Route("api/detallesfacturaproveedor")]
    public class ControladorDetallesFacturaProveedor : ControllerBase
    {
        private readonly IServiceManager _service;

        public ControladorDetallesFacturaProveedor(IServiceManager service) =>
            _service = service;

        [HttpGet]
        public IActionResult GetallDetallesFacturaProveedores()
        {
            //throw new Exception("Exception");
            var detallesfacturaproveedores = _service.ServicioDetallesFacturaProveedor.GetAllDetallesFacturaProveedor(trackChanges: false);
            return Ok(detallesfacturaproveedores);


        }
        [HttpGet("{DetalleId:guid}")]
        public IActionResult GetDetallesFacturaProveedor(Guid DetalleId)
        {
            var detallesfacturaproveedor = _service.ServicioDetallesFacturaProveedor.GetDetallesFacturaProveedor(DetalleId, trackChanges: false);
            return Ok(detallesfacturaproveedor);
        }
    }
}