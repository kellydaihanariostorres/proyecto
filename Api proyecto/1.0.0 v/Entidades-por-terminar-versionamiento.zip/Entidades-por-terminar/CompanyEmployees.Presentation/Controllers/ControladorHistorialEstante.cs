﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Service.Contracts;
using Shared.DataTransferObject;

namespace CompanyEmployees.Presentation.Controllers
{
    [ApiController]
    [Route("api/historialestante")]
    public class ControladorHistorialEstante : ControllerBase
    {
        private readonly IServiceManager _service;

        public ControladorHistorialEstante(IServiceManager service) =>
            _service = service;

        [HttpGet]
        public IActionResult GetallHistorialEstantes()
        {

            var historialEstantes = _service.ServicioHistorialEstante.GetAllHistorialEstantes(trackChanges: false);
            return Ok(historialEstantes);


        }
        [HttpGet("{HistorialEstanteId:guid}", Name = "HistorialEstanteById")]
        public IActionResult GetHistorialEstante(Guid historialEstanteId)
        {
            var historialEstante = _service.ServicioHistorialEstante.GetHistorialEstante(historialEstanteId, trackChanges: false);
            return Ok(historialEstante);
        }
        [HttpPost]
        public IActionResult CreateHistorialEstante([FromBody] CrearHistorialEstanteDto historialEstante)
        {
            if (historialEstante is null)
                return BadRequest("CompanyForCreationDto object is null");

            var crearhistorialEstante = _service.ServicioHistorialEstante.CreateHistorialEstante(historialEstante);

            return CreatedAtRoute("BodegaById", new { historialEstanteId = crearhistorialEstante.HistorialEstanteId }, crearhistorialEstante);
        }
    }
}
