﻿using Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts
{
    public interface IHistorialEstanteRepositorio
    {
        IEnumerable<HistorialEstante> GetAllHistorialEstantes(bool trackChanges);
        HistorialEstante GetHistorialEstante(Guid historialEstanteId, bool trackChanges);
        void CreateHistorialEstante(HistorialEstante historialEstante);

    }
}
