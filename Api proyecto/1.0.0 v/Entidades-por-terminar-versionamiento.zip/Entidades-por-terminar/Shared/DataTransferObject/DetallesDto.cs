﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.DataTransferObject
{
    public record DetallesDto(Guid DetallesId, string Iva, string ValorUnidad, string Cantidad, string CajeroNombre, string CajeroId);

}
