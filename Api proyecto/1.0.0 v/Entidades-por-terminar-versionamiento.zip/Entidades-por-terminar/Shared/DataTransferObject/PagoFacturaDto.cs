﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.DataTransferObject
{
    public record PagoFacturaDto(Guid PagoFacturaId, string IdFactura, string Banco, string Contraseña, string ConsultarCupo, DateTime FechaTransaccion);

}
