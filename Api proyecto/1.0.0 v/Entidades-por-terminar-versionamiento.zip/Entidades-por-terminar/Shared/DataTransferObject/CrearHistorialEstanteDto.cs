﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.DataTransferObject
{
    public record CrearHistorialEstanteDto(string EstanteId, string TipoMovimiento, string Observaciones,
           IEnumerable<CrearHistorialEstanteDto> crearHistorialEstante);

}
