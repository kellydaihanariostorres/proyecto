﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.DataTransferObject
{
    public record EstanteDto(Guid EstanteId, string ProductoId, string Cantidad);

}
