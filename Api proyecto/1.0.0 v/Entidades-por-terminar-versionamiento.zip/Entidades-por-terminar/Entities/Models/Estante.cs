﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Models
{
    public class Estante
    {
        [Column("EstanteId")]
        [Key]
        public Guid EstanteId { get; set; }
        [Required(ErrorMessage = "Se requiere el id del producto para el estante.")]
        [MaxLength(100, ErrorMessage = "La longitud máxima del nombre es de 100 caracteres..")]
        public string? ProductoId { get; set; }

        [Required(ErrorMessage = "Se requiere la cantidad para el estante.")]
        [MaxLength(1000, ErrorMessage = "La longitud máxima del nombre es de 1000 caracteres..")]
        public string? Cantidad { get; set; }

        //Si necesito información de otra tabla
        //[ForeignKey(nameof(Company))]
        //public Guid CompanyId { get; set; }
        //public Company? Company { get; set; }

    }
}
