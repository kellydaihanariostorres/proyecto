﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Models
{
    public class PagoFactura
    {
        [Column("PagoFacturaId")]
        [Key]
        public Guid PagoFacturaId { get; set; }

        [Required(ErrorMessage = "Id de la factura es requerida para el campo.")]
        [MaxLength(50, ErrorMessage = "Maximo de caracteres es de 50.")]
        public string? IdFactura { get; set; }

        [Required(ErrorMessage = "el banco es requerido para el campo.")]
        [MaxLength(100, ErrorMessage = "Maximo de caracteres es de 100.")]
        public string? Banco { get; set; }

        [Required(ErrorMessage = "La contraseña es requerida para el campo.")]
        [MaxLength(10, ErrorMessage = "Maximo de caracteres es de 10.")]
        public string? Contraseña { get; set; }

        [Required(ErrorMessage = "Consultar cupo es requerido para el campo.")]
        [MaxLength(100, ErrorMessage = "Maximo de caracteres es de 100.")]
        public string? ConsultarCupo { get; set; }

        [Required(ErrorMessage = "La fecha de transaccion es requerida para el campo.")]
        public DateTime? FechaTransaccion { get; set; }

        public ICollection<Empleado>? Empleados { get; set; }
    }
}
