﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Models
{
    public class Detalles
    {
        [Column("DetallesId")]
        [Key]
        public Guid DetallesId { get; set; }

        [Required(ErrorMessage = "Se requiere un IVA para el producto.")]
        [MaxLength(1000000, ErrorMessage = "La longitud máxima del nombre es de 1000000 caracteres..")]
        public string? Iva { get; set; }

        [Required(ErrorMessage = "Se requiere un ValorUnidad para el producto.")]
        [MaxLength(1000000, ErrorMessage = "La longitud máxima del nombre es de 1000000 caracteres..")]
        public string? ValorUnidad { get; set; }


        [Required(ErrorMessage = "La Cantidad es obligatoria.")]
        [MaxLength(1000, ErrorMessage = "La longitud máxima para la edad es de 1000.")]
        public string? Cantidad { get; set; }

        [Required(ErrorMessage = "El numero Nombre del Cajero es un campo obligatorio..")]
        [MaxLength(50, ErrorMessage = "La longitud máxima para el número de documento es de 50 caracteres.")]
        public string? CajeroNombre { get; set; }

        [Required(ErrorMessage = "El numero de documento es un campo obligatorio..")]
        [MaxLength(15, ErrorMessage = "La longitud máxima para el número de documento es de 15 caracteres.")]
        public string? CajeroId { get; set; }
        
        //Si necesito información de otra tabla
        //[ForeignKey(nameof(Company))]
        //public Guid CompanyId { get; set; }
        //public Company? Company { get; set; }

    }
}