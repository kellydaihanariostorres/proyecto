﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Models
{

    public class Stock
    {
        [Column("StockId")]
        [Key]
        public Guid StockId { get; set; }

        [Required(ErrorMessage = "Id de inventario es requerido para el campo.")]
        [MaxLength(50, ErrorMessage = "Maximo de caracteres es de 50.")]
        public string? IdInventario { get; set; }

        [Required(ErrorMessage = "La cantidad maxima es requerido para el campo.")]
        [MaxLength(100, ErrorMessage = "Maximo de caracteres es de 100.")]
        public string? CantMaxProducto { get; set; }

        [Required(ErrorMessage = "La cantidad minima es requerida para el campo.")]
        [MaxLength(100, ErrorMessage = "Maximo de caracteres es de 100.")]
        public string? CantMinProducto { get; set; }

        public ICollection<Inventario>? Inventario { get; set; }
    }
}
