﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Models
{

    public class DetallesFacturaProveedor
    {
        [Column("DetallesFacturaProveedorId")]
        [Key]
        public Guid DetalleId { get; set; }

        [Required(ErrorMessage = "El producto es requerido para el campo.")]
        [MaxLength(100, ErrorMessage = "Maximo de caracteres es de 100.")]
        public string? Producto { get; set; }

        [Required(ErrorMessage = "La Cantidad es requerida para el campo.")]
        [MaxLength(1000, ErrorMessage = "Maximo de caracteres es de 1000.")]
        public string? Cantidad { get; set; }
        
    }
}