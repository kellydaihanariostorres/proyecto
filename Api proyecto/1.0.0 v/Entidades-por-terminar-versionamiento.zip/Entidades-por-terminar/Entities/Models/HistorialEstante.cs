﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Models
{

    public class HistorialEstante
    {
        [Column("HistorialEstanteId")]
        [Key]
        public Guid HistorialEstanteId { get; set; }

        [Required(ErrorMessage = "El estante Id es requerido para el campo.")]
        [MaxLength(50, ErrorMessage = "Maximo de caracteres es de 50.")]
        public string? EstanteId { get; set; }

        [Required(ErrorMessage = "El tipo de movimiento es requerido para el campo.")]
        [MaxLength(50, ErrorMessage = "Maximo de caracteres es de 50.")]
        public string? TipoMovimiento { get; set; }

        [Required(ErrorMessage = "Las observaciones son requeridas para el campo.")]
        [MaxLength(50, ErrorMessage = "Maximo de caracteres es de 50.")]
        public string? Observaciones { get; set; }
    }
}
