﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Models
{

    public class PagoProveedores
    {
        [Column("PagoProveedoresId")]
        [Key]
        public Guid PagoProveedoresId { get; set; }

        [Required(ErrorMessage = "El Nit es requerido para el campo.")]
        [MaxLength(100, ErrorMessage = "Maximo de caracteres es de 100.")]
        public string? NumeroNit { get; set; }

        [Required(ErrorMessage = "El nombre es requerido para el campo.")]
        [MaxLength(100, ErrorMessage = "Maximo de caracteres es de 100.")]
        public string? Nombre { get; set; }

        [Required(ErrorMessage = "El id del proveedor es requerido para el campo.")]
        [MaxLength(50, ErrorMessage = "Maximo de caracteres es de 50.")]
        public string? IdProveedor { get; set; }
    }
}
