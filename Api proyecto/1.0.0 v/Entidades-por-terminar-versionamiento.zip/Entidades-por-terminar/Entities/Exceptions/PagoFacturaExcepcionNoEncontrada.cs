﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Exceptions
{
    public sealed class PagoFacturaExcepcionNoEncontrada : NotFoundException
    {
        public PagoFacturaExcepcionNoEncontrada(Guid pagoFacturaId)
            : base($"El pago con id:{pagoFacturaId} no existe en la base de datos.")
        {
        }
    }
}