﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Exceptions
{
    public sealed class PagoProveedorExcepcionNoEncontrada : NotFoundException
    {
        public PagoProveedorExcepcionNoEncontrada(Guid pagoProveedoresId)
        : base($"El pago a proveedor con id:{pagoProveedoresId} no existe en la base de datos.")
        {
        }
    }
}
