﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Exceptions
{
    public sealed class StockExcepcionNoEncontrada : NotFoundException
    {
        public StockExcepcionNoEncontrada(Guid StockId)
            : base($"El stock con el id:{StockId} no existe en la base de datos.")
        {
        }
    }
}
