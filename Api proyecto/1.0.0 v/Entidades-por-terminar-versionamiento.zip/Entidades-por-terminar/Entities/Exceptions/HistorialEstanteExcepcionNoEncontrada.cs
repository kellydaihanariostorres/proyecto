﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Exceptions
{
    public sealed class HistorialEstanteExcepcionNoEncontrada : NotFoundException
    {
        public HistorialEstanteExcepcionNoEncontrada(Guid historialEstanteId)
        : base($"El historial de estante con id:{historialEstanteId} no existe en la base de datos.")
        {
        }
    }
}
