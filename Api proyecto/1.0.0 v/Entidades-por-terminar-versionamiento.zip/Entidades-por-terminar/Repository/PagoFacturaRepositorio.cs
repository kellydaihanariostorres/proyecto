﻿using Contracts;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    internal sealed class PagoFacturaRepositorio : RepositoryBase<PagoFactura>, IPagoFacturaRepositorio
    {
        public PagoFacturaRepositorio(RepositoryContext repositoryContext)
            : base(repositoryContext)
        {

        }

        public IEnumerable<PagoFactura> GetAllPagoFacturas(bool trackChanges) =>
            FindAll(trackChanges)
            .OrderBy(n => n.IdFactura)
            .ToList();

        public PagoFactura GetPagoFacturas(Guid pagoFacturaId, bool trackChanges) =>
            FindByCondition(x => x.PagoFacturaId.Equals(pagoFacturaId), trackChanges)
            .SingleOrDefault();

    }
}
