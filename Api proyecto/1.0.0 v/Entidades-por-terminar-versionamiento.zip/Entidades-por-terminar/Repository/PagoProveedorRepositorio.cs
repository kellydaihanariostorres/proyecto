﻿using Contracts;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    internal sealed class PagoProveedorRepositorio : RepositoryBase<PagoProveedores>, IPagoProveedorRepositorio
    {
        public PagoProveedorRepositorio(RepositoryContext repositoryContext)
            : base(repositoryContext)
        {

        }

        public IEnumerable<PagoProveedores> GetAllPagoProveedores(bool trackChanges) =>
            FindAll(trackChanges)
            .OrderBy(n => n.NumeroNit)
            .ToList();

        public PagoProveedores GetPagoProveedor(Guid pagoProveedorId, bool trackChanges) =>
            FindByCondition(x => x.PagoProveedoresId.Equals(pagoProveedorId), trackChanges)
            .SingleOrDefault();

    }
}
