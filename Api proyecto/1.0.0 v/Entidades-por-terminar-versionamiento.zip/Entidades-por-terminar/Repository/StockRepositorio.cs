﻿using Contracts;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    internal sealed class StockRepositorio : RepositoryBase<Stock>, IStockRepositorio
    {
        public StockRepositorio(RepositoryContext repositoryContext)
            : base(repositoryContext)
        {

        }

        public IEnumerable<Stock> GetAllStocks(bool trackChanges) =>
            FindAll(trackChanges)
            .OrderBy(n => n.IdInventario)
            .ToList();

        public Stock GetStock(Guid stockId, bool trackChanges) =>
            FindByCondition(c => c.StockId.Equals(stockId), trackChanges)
            .SingleOrDefault();

    }
}
