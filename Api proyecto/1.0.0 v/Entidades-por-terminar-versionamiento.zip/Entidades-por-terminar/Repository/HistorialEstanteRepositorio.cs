﻿using Contracts;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository;

internal sealed class HistorialEstanteRepositorio : RepositoryBase<HistorialEstante>, IHistorialEstanteRepositorio
{
    public HistorialEstanteRepositorio(RepositoryContext repositoryContext)
        : base(repositoryContext)
    {

    }

    public IEnumerable<HistorialEstante> GetAllHistorialEstantes(bool trackChanges) =>
        FindAll(trackChanges)
        .OrderBy(n => n.EstanteId)
        .ToList();

    public HistorialEstante GetHistorialEstante(Guid historialEstanteId, bool trackChanges) =>
        FindByCondition(c => c.HistorialEstanteId.Equals(historialEstanteId), trackChanges)
        .SingleOrDefault();

    public void CreateHistorialEstante(HistorialEstante historialEstante) => Create(historialEstante);
}