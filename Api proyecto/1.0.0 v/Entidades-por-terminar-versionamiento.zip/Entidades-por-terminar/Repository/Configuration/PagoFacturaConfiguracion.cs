﻿using Entities.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Configuration
{
    public class PagoFacturaConfiguracion : IEntityTypeConfiguration<PagoFactura>
    {
        public void Configure(EntityTypeBuilder<PagoFactura> builder)
        {
            builder.HasData(
                new PagoFactura
                {
                    PagoFacturaId = new Guid("c9d4c053-49b6-410c-bc78-2d54a9991870"),
                    IdFactura = "9999",
                    Banco = "Nequi",
                    Contraseña = "00000",
                    ConsultarCupo = "Valido",
                    FechaTransaccion = new DateTime(2020/08/2),
                    
                },
                new PagoFactura
                {
                    PagoFacturaId = new Guid("c9d4c053-49b6-410c-bc78-2d54a9998880"),
                    IdFactura = "777",
                    Banco = "Bancolombia",
                    Contraseña = "33333",
                    ConsultarCupo = "Invalido",
                    FechaTransaccion = new DateTime(2023 / 01 / 28),

                },
                new PagoFactura
                {
                    PagoFacturaId = new Guid("c9d4c053-49b6-410c-bc78-2d54a9978980"),
                    IdFactura = "212",
                    Banco = "Davivienda",
                    Contraseña = "123456789",
                    ConsultarCupo = "Valido",
                    FechaTransaccion = new DateTime(2022 / 05 / 28),

                }
            );
        }
    }
}