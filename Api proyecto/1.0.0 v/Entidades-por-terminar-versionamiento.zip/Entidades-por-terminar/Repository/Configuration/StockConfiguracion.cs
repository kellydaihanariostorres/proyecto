﻿using Entities.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Configuration
{
    public class StockConfiguracion : IEntityTypeConfiguration<Stock>
    {
        public void Configure(EntityTypeBuilder<Stock> builder)
        {
            builder.HasData(
                new Stock
                {
                    StockId = new Guid("c9d4c053-49b6-410c-bc78-2d54a9991888"),
                    IdInventario = "c9d4c053-49b6-410c-bc78-2d54a9991870",
                    CantMaxProducto = "55",
                    CantMinProducto = "1"
                   
                },
                new Stock
                {
                    StockId = new Guid("3d490a70-94ce-4d15-9494-5248280c2222"),
                    IdInventario = "C4444444444444444444444444444445",
                    CantMaxProducto = "50",
                    CantMinProducto = "1"
                }
            );
        }
    }
}