﻿using Entities.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Repository.Configuration
{
    public class DetallesConfiguracion : IEntityTypeConfiguration<Detalles>
    {
        public void Configure(EntityTypeBuilder<Detalles> builder)
        {
            builder.HasData
            (
                new Detalles
                {
                    DetallesId = new Guid("F69B4D8A-4936-4A09-81ED-C76FD00BDB46"),
                    Iva = "7000",
                    ValorUnidad = "30000",
                    Cantidad = "",
                    CajeroNombre = "Johan Murcia",
                    CajeroId = "254811315"
                },
                new Detalles
                {
                    DetallesId = new Guid("D3B083EF-2E9A-438F-867B-67FCC8F136BB"),
                    Iva = "8500",
                    ValorUnidad = "60000",
                    Cantidad = "2",
                    CajeroNombre = "Kevin Marin",
                    CajeroId = "310021151",
                }
            ); ;
        }
    }
}
