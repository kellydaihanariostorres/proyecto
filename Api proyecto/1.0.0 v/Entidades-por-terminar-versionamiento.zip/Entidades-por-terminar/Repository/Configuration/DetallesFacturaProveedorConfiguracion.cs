﻿using Entities.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Configuration
{
    public class DetallesFacturaProveedorConfiguracion : IEntityTypeConfiguration<DetallesFacturaProveedor>
    {
        public void Configure(EntityTypeBuilder<DetallesFacturaProveedor> builder)
        {
            builder.HasData(
                new DetallesFacturaProveedor
                {
                    DetalleId = new Guid("c9d4c053-49b6-410c-bc50-2d54a9991870"),
                    Producto = "Vino Gato Negro",
                    Cantidad = "2000",
                
                },
                new DetallesFacturaProveedor
                {
                    DetalleId = new Guid("c9d4c053-49b6-410c-bc40-2d54a9991870"),
                    Producto = "Cerveza Poker",
                    Cantidad = "1500",
                },
                new DetallesFacturaProveedor
                {
                    DetalleId = new Guid("c9d4c053-49b6-410c-bc60-2d54a9991870"),
                    Producto = "Whisky Jack Daniels",
                    Cantidad = "250",
                }
            );
        }
    }
}