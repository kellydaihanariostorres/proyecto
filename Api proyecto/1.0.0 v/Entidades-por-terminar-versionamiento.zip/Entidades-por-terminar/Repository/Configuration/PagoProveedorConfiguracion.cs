﻿using Entities.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Configuration
{
    public class PagoProveedorConfiguracion : IEntityTypeConfiguration<PagoProveedores>
    {
        public void Configure(EntityTypeBuilder<PagoProveedores> builder)
        {
            builder.HasData(
                new PagoProveedores
                {
                    PagoProveedoresId = new Guid("c9d4c053-49b6-410c-bc78-2d54a9991222"),
                    NumeroNit = "123456789",
                    Nombre = "Nicolas Rodriguez",
                    IdProveedor = "08000",
                    
                },
                 new PagoProveedores
                 {
                     PagoProveedoresId = new Guid("c9d4c053-49b6-410c-bc78-2d54a9991111"),
                     NumeroNit = "987654321",
                     Nombre = "Carlos Andres",
                     IdProveedor = "10666",

                 }

            );
        }
    }
}
