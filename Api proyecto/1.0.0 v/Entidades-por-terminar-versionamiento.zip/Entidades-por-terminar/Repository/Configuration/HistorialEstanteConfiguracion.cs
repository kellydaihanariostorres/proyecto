﻿using Entities.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Configuration
{
    public class HistorialEstanteConfiguracion : IEntityTypeConfiguration<HistorialEstante>
    {
        public void Configure(EntityTypeBuilder<HistorialEstante> builder)
        {
            builder.HasData(
                new HistorialEstante
                {
                    HistorialEstanteId = new Guid("c9d4c053-49b6-410c-bc78-2d54a9992001"),
                    EstanteId = "020304",
                    TipoMovimiento = "Entrada Licores",
                    Observaciones = "Se recibieron 35 botellas de vino Gato Negro",
                    
                },
                new HistorialEstante
                {
                    HistorialEstanteId = new Guid("c9d4c053-49b6-410c-bc78-2d54a9992000"),
                    EstanteId = "020305",
                    TipoMovimiento = "Salida Cervezas",
                    Observaciones = "Se vendieron 100 cervezas poker",
                }
            );
        }
    }
}
