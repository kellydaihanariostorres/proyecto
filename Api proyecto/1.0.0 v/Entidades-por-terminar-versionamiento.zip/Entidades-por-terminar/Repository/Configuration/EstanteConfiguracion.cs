﻿using Entities.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Repository.Configuration
{
    public class EstanteConfiguracion : IEntityTypeConfiguration<Estante>
    {
        public void Configure(EntityTypeBuilder<Estante> builder)
        {
            builder.HasData
            (
                new Estante
                {
                    EstanteId = new Guid("A02EC1A3-5A99-4038-9E47-951661A0F396"),
                    ProductoId = "80abbca8-664d-4b21-b5de-024705497d4a",
                    Cantidad = "1500"
                   
                },
                new Estante
                {
                    EstanteId = new Guid("925E1919-AB0E-4494-9455-9159BC5BB140"),
                    ProductoId = "80abbca5-664d-4b22-b5de-024705497d4a",
                    Cantidad = "2000"
                }
            ); ;
        }
    }
}