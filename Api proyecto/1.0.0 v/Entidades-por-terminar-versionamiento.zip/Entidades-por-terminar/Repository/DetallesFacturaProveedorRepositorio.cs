﻿using Contracts;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    internal sealed class DetallesFacturaProveedorRepositorio : RepositoryBase<DetallesFacturaProveedor>, IDetallesFacturaProveedorRepositorio
    {
        public DetallesFacturaProveedorRepositorio(RepositoryContext repositoryContext)
            : base(repositoryContext)
        {

        }

        public IEnumerable<DetallesFacturaProveedor> GetAllDetallesFacturaProveedor(bool trackChanges) =>
            FindAll(trackChanges)
            .OrderBy(n => n.Producto)
            .ToList();

        public DetallesFacturaProveedor GetDetallesFacturaProveedor(Guid detalleId, bool trackChanges) =>
            FindByCondition(c => c.DetalleId.Equals(detalleId), trackChanges)
            .SingleOrDefault();

    }
}