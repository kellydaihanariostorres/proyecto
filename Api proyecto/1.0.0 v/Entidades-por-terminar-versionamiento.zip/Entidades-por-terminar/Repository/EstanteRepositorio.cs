﻿using Contracts;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    internal sealed class EstanteRepositorio : RepositoryBase<Estante>, IEstanteRepositorio
    {
        public EstanteRepositorio(RepositoryContext repositoryContext)
            : base(repositoryContext)
        {

        }

        public IEnumerable<Estante> GetAllEstantes(bool trackChanges) =>
            FindAll(trackChanges)
            .OrderBy(n => n.ProductoId)
            .ToList();

        public Estante GetEstante(Guid estanteId, bool trackChanges) =>
            FindByCondition(n => n.EstanteId.Equals(estanteId), trackChanges)
            .SingleOrDefault();

    }
}