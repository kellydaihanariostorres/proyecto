﻿using Contracts;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    internal sealed class DetallesRepositorio : RepositoryBase<Detalles>, IDetallesRepositorio
    {
        public DetallesRepositorio(RepositoryContext repositoryContext)
            : base(repositoryContext)
        {

        }

        public IEnumerable<Detalles> GetAllDetalles(bool trackChanges) =>
            FindAll(trackChanges)
            .OrderBy(n => n.DetallesId)
            .ToList();

        public Detalles GetDetalle(Guid detalleId, bool trackChanges) =>
            FindByCondition(n => n.Iva.Equals(detalleId), trackChanges)
            .SingleOrDefault();

    }
}
