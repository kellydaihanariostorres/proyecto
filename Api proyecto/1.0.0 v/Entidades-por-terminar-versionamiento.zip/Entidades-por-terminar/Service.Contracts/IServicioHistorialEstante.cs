﻿
using Shared.DataTransferObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service.Contracts
{
    public interface IServicioHistorialEstante
    {
        IEnumerable<HistorialEstanteDto> GetAllHistorialEstantes(bool trackChanges);
        HistorialEstanteDto GetHistorialEstante(Guid historialEstanteId, bool trackChanges);

        HistorialEstanteDto CreateHistorialEstante(CrearHistorialEstanteDto historialEstante);
    }
}
