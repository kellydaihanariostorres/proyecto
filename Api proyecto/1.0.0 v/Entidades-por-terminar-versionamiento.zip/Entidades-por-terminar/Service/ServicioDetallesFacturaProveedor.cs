﻿using AutoMapper;
using Contracts;
using Entities.Exceptions;
using Entities.Models;
using Service.Contracts;
using Shared.DataTransferObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service
{
    internal sealed class ServicioDetallesFacturaProveedor : IServicioDetalleFacturaProveedor
    {
        private readonly IRepositoryManager _repository;
        private readonly ILoggerManager _logger;
        private readonly IMapper _mapper;

        public ServicioDetallesFacturaProveedor(IRepositoryManager repository, ILoggerManager logger, IMapper mapper)
        {
            _repository = repository;
            _logger = logger;
            _mapper = mapper;
        }

        public IEnumerable<DetallesFacturaProveedorDto> GetAllDetallesFacturaProveedor(bool trackChanges)
        {

            var detallesfacturaproveedor = _repository.DetallesFacturaProveedor.GetAllDetallesFacturaProveedor(trackChanges);

            //var companiesDto = companies.Select(c => new CompanyDto(c.Id, c.Name ??"", string.Join(' ', c.Address, c.Country))).ToList();
            var detallesFacturaProveedorDto = _mapper.Map<IEnumerable<DetallesFacturaProveedorDto>>(detallesfacturaproveedor);
            return detallesFacturaProveedorDto;

        }

        public DetallesFacturaProveedorDto GetDetallesFacturaProveedor(Guid detalleId, bool trackChanges)
        {
            var detallesfacturaproveedor = _repository.DetallesFacturaProveedor.GetDetallesFacturaProveedor(detalleId, trackChanges);
            //Check if the company is null
            if (detallesfacturaproveedor is null)
                throw new DetallesFacturaProveedorExcepcionNoEncontrada(detalleId);

            var detallesfacturaproveedorDto = _mapper.Map<DetallesFacturaProveedorDto>(detallesfacturaproveedor);

            return detallesfacturaproveedorDto;
        }
    }
}
