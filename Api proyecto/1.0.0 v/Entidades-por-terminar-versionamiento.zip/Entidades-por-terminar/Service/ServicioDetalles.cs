﻿using AutoMapper;
using Contracts;
using Entities.Exceptions;
using Service.Contracts;
using Shared.DataTransferObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service
{
    internal sealed class ServicioDetalles : IServicioDetalles
    {
        private readonly IRepositoryManager _repository;
        private readonly ILoggerManager _logger;
        private readonly IMapper _mapper;

        public ServicioDetalles(IRepositoryManager repository, ILoggerManager logger, IMapper mapper)
        {
            _repository = repository;
            _logger = logger;
            _mapper = mapper;
        }

        public IEnumerable<DetallesDto> GetAllDetalles(bool trackChanges)
        {

            var detalles = _repository.Detalles.GetAllDetalles(trackChanges);

            //var companiesDto = companies.Select(c => new CompanyDto(c.Id, c.Name ??"", string.Join(' ', c.Address, c.Country))).ToList();
            var detallesDto = _mapper.Map<IEnumerable<DetallesDto>>(detalles);
            return detallesDto;

        }


        public DetallesDto GetDetalle(Guid detalleId, bool trackChanges)
        {
            var detalle = _repository.Cliente.GetCliente(detalleId, trackChanges);
            //Check if the company is null
            if (detalle is null)
                throw new DetallesExcepcionNoEncontrada(detalleId);

            var detalleDto = _mapper.Map<DetallesDto>(detalle);
            return detalleDto;
        }
    }
}
