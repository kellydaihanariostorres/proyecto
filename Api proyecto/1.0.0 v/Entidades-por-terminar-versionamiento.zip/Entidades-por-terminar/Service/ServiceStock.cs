﻿using AutoMapper;
using Contracts;
using Entities.Exceptions;
using Entities.Models;
using Service.Contracts;
using Shared.DataTransferObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service
{
    internal sealed class ServicioStock : IServicioStock
    {
        private readonly IRepositoryManager _repository;
        private readonly ILoggerManager _logger;
        private readonly IMapper _mapper;

        public ServicioStock(IRepositoryManager repository, ILoggerManager logger, IMapper mapper)
        {
            _repository = repository;
            _logger = logger;
            _mapper = mapper;
        }

        public IEnumerable<StockDto> GetAllStocks(bool trackChanges)
        {

            var stocks = _repository.Stock.GetAllStocks(trackChanges);

            //var companiesDto = companies.Select(c => new CompanyDto(c.Id, c.Name ??"", string.Join(' ', c.Address, c.Country))).ToList();
            var StocksDto = _mapper.Map<IEnumerable<StockDto>>(stocks);
            return StocksDto;

        }

        public StockDto GetStock(Guid stockId, bool trackChanges)
        {
            var stock = _repository.Stock.GetStock(stockId, trackChanges);
            //Check if the company is null
            if (stock is null)
                throw new StockExcepcionNoEncontrada(stockId);

            var stockDto = _mapper.Map<StockDto>(stock);

            return stockDto;
        }
    }
}

