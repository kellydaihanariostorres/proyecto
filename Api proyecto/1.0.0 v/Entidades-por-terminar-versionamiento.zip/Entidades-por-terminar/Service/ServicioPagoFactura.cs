﻿using AutoMapper;
using Contracts;
using Entities.Exceptions;
using Entities.Models;
using Service.Contracts;
using Shared.DataTransferObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service
{
    internal sealed class ServicioPagoFactura : IServicioPagoFactura
    {
        private readonly IRepositoryManager _repository;
        private readonly ILoggerManager _logger;
        private readonly IMapper _mapper;

        public ServicioPagoFactura(IRepositoryManager repository, ILoggerManager logger, IMapper mapper)
        {
            _repository = repository;
            _logger = logger;
            _mapper = mapper;
        }

        public IEnumerable<PagoFacturaDto> GetAllPagoFacturas(bool trackChanges)
        {

            var pagoFacturas = _repository.PagoFactura.GetAllPagoFacturas(trackChanges);

            //var companiesDto = companies.Select(c => new CompanyDto(c.Id, c.Name ??"", string.Join(' ', c.Address, c.Country))).ToList();
            var pagoFacturasDto = _mapper.Map<IEnumerable<PagoFacturaDto>>(pagoFacturas);
            return pagoFacturasDto;

        }

        public PagoFacturaDto GetPagoFactura(Guid pagoFacturaId, bool trackChanges)
        {
            var pagoFactura = _repository.PagoFactura.GetPagoFacturas(pagoFacturaId, trackChanges);
            //Check if the company is null
            if (pagoFactura is null)
                throw new PagoFacturaExcepcionNoEncontrada(pagoFacturaId);

            var pagoFacturaDto = _mapper.Map<PagoFacturaDto>(pagoFactura);

            return pagoFacturaDto;
        }
    }
    
}
