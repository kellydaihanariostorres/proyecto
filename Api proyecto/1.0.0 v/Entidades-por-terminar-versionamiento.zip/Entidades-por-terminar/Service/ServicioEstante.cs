﻿using AutoMapper;
using Contracts;
using Entities.Exceptions;
using Service.Contracts;
using Shared.DataTransferObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service
{
    internal sealed class ServicioEstante : IServicioEstante
    {
        private readonly IRepositoryManager _repository;
        private readonly ILoggerManager _logger;
        private readonly IMapper _mapper;

        public ServicioEstante(IRepositoryManager repository, ILoggerManager logger, IMapper mapper)
        {
            _repository = repository;
            _logger = logger;
            _mapper = mapper;
        }

        public IEnumerable<EstanteDto> GetAllEstante(bool trackChanges)
        {

            var estante = _repository.Estante.GetAllEstantes(trackChanges);

            //var companiesDto = companies.Select(c => new CompanyDto(c.Id, c.Name ??"", string.Join(' ', c.Address, c.Country))).ToList();
            var estantesDto = _mapper.Map<IEnumerable<EstanteDto>>(estante);
            return estantesDto;

        }


        public EstanteDto GetEstante(Guid estanteId, bool trackChanges)
        {
            var estante = _repository.Estante.GetEstante(estanteId, trackChanges);
            //Check if the company is null
            if (estante is null)
                throw new EstanteExcepcionNoEncontrada(estanteId);

            var estanteDto = _mapper.Map<EstanteDto>(estante);
            return estanteDto;
        }
    }
}