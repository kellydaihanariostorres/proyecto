﻿using AutoMapper;
using Contracts;
using Entities.Exceptions;
using Entities.Models;
using Service.Contracts;
using Shared.DataTransferObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service
{
    internal sealed class ServicioPagoProveedor : IServicioPagoProveedor
    {
        private readonly IRepositoryManager _repository;
        private readonly ILoggerManager _logger;
        private readonly IMapper _mapper;

        public ServicioPagoProveedor(IRepositoryManager repository, ILoggerManager logger, IMapper mapper)
        {
            _repository = repository;
            _logger = logger;
            _mapper = mapper;
        }

        public IEnumerable<PagoProveedorDto> GetAllPagoProveedores(bool trackChanges)
        {

            var pagoProveedores = _repository.PagoProveedor.GetAllPagoProveedores(trackChanges);

            //var companiesDto = companies.Select(c => new CompanyDto(c.Id, c.Name ??"", string.Join(' ', c.Address, c.Country))).ToList();
            var pagoProveedoresDto = _mapper.Map<IEnumerable<PagoProveedorDto>>(pagoProveedores);
            return pagoProveedoresDto;

        }

        public PagoProveedorDto GetPagoProveedor(Guid pagoProveedoresId, bool trackChanges)
        {
            var pagoProveedor = _repository.PagoProveedor.GetPagoProveedor(pagoProveedoresId, trackChanges);
            //Check if the company is null
            if (pagoProveedor is null)
                throw new PagoProveedorExcepcionNoEncontrada(pagoProveedoresId);

            var pagoProveedorDto = _mapper.Map<PagoProveedorDto>(pagoProveedor);

            return pagoProveedorDto;
        }
    }
}
