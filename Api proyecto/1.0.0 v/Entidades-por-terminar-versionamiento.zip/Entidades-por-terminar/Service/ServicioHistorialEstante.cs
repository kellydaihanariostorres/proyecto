﻿using AutoMapper;
using Contracts;
using Entities.Exceptions;
using Entities.Models;
using Service.Contracts;
using Shared.DataTransferObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service
{
    internal sealed class ServicioHistorialEstante : IServicioHistorialEstante
    {
        private readonly IRepositoryManager _repository;
        private readonly ILoggerManager _logger;
        private readonly IMapper _mapper;

        public ServicioHistorialEstante(IRepositoryManager repository, ILoggerManager logger, IMapper mapper)
        {
            _repository = repository;
            _logger = logger;
            _mapper = mapper;
        }

        public IEnumerable<HistorialEstanteDto> GetAllHistorialEstantes(bool trackChanges)
        {

            var historialEstantes = _repository.HistorialEstante.GetAllHistorialEstantes(trackChanges);


            var historialEstanteDto = _mapper.Map<IEnumerable<HistorialEstanteDto>>(historialEstantes);
            return historialEstanteDto;

        }

        public HistorialEstanteDto GetHistorialEstante(Guid historialEstanteId, bool trackChanges)
        {
            var historialEstante = _repository.HistorialEstante.GetHistorialEstante(historialEstanteId, trackChanges);

            if (historialEstante is null)
            {
                throw new HistorialEstanteExcepcionNoEncontrada(historialEstanteId);
            }


            var historialEstanteDto = _mapper.Map<HistorialEstanteDto>(historialEstante);

            return historialEstanteDto;
        }

        public HistorialEstanteDto CreateHistorialEstante(CrearHistorialEstanteDto historialEstante)
        {
            var entidadhistorialEstante = _mapper.Map<HistorialEstante>(historialEstante);

            _repository.HistorialEstante.CreateHistorialEstante(entidadhistorialEstante);
            _repository.Save();

            var retornahistorialEstantes = _mapper.Map<HistorialEstanteDto>(entidadhistorialEstante);

            return retornahistorialEstantes;
        }

    }
}
