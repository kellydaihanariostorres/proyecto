﻿using AutoMapper;
using Contracts;
using Entities.Exceptions;
using Entities.Models;
using Service.Contracts;
using Shared.DataTransferObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service
{
    internal sealed class ServicioEmpleado : IServicioEmpleado
    {
        private readonly IRepositoryManager _repository;
        private readonly ILoggerManager _logger;
        private readonly IMapper _mapper;

        public ServicioEmpleado(IRepositoryManager repository, ILoggerManager logger, IMapper mapper)
        {
            _repository = repository;
            _logger = logger;
            _mapper = mapper;
        }
        public IEnumerable<EmpleadoDto> GetAllEmpleados( bool trackChanges)
        {
           
                var empleados = _repository.Empleado.GetAllEmpleados(trackChanges);

                var employeesDto = _mapper.Map<IEnumerable<EmpleadoDto>>(empleados);
                return employeesDto;
            
        }


        public IEnumerable<EmpleadoDto> GetEmpleados(Guid bodegaId, bool trackChanges)
        {
            var bodega = _repository.Empleado.GetEmpleados(bodegaId, trackChanges);
            if (bodega is null)
                throw new CompanyNotFoundException(bodegaId);

          
         var employeesFromDb = _repository.Empleado.GetEmpleados(bodegaId,
         trackChanges);
                    var employeesDto = _mapper.Map<IEnumerable<EmpleadoDto>>(employeesFromDb);
                return employeesDto;
        }

    }
}
