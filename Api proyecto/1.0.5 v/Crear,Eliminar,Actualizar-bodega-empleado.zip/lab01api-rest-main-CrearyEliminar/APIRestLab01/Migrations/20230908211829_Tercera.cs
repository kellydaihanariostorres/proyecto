﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace APIRestLab01.Migrations
{
    /// <inheritdoc />
    public partial class Tercera : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Facturas",
                keyColumn: "FacturaId",
                keyValue: new Guid("64b512e7-46ae-4989-a049-a446118099c4"),
                column: "FechaCompra",
                value: new DateTime(2023, 9, 8, 16, 18, 29, 816, DateTimeKind.Local).AddTicks(4090));

            migrationBuilder.UpdateData(
                table: "Facturas",
                keyColumn: "FacturaId",
                keyValue: new Guid("fd713788-b5ae-49ff-8b2c-f311b9cb0cc4"),
                column: "FechaCompra",
                value: new DateTime(2023, 9, 8, 16, 18, 29, 816, DateTimeKind.Local).AddTicks(4075));

            migrationBuilder.UpdateData(
                table: "Nominas",
                keyColumn: "Id",
                keyValue: new Guid("376d45c8-659d-4ace-b249-cfbf4f231915"),
                column: "FechaCreacion",
                value: new DateTime(2023, 9, 8, 16, 18, 29, 816, DateTimeKind.Local).AddTicks(4365));

            migrationBuilder.UpdateData(
                table: "Nominas",
                keyColumn: "Id",
                keyValue: new Guid("c9d4c053-49b6-410c-bc78-2d54a9991872"),
                column: "FechaCreacion",
                value: new DateTime(2023, 9, 8, 16, 18, 29, 816, DateTimeKind.Local).AddTicks(4360));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Facturas",
                keyColumn: "FacturaId",
                keyValue: new Guid("64b512e7-46ae-4989-a049-a446118099c4"),
                column: "FechaCompra",
                value: new DateTime(2023, 9, 8, 13, 39, 49, 425, DateTimeKind.Local).AddTicks(5077));

            migrationBuilder.UpdateData(
                table: "Facturas",
                keyColumn: "FacturaId",
                keyValue: new Guid("fd713788-b5ae-49ff-8b2c-f311b9cb0cc4"),
                column: "FechaCompra",
                value: new DateTime(2023, 9, 8, 13, 39, 49, 425, DateTimeKind.Local).AddTicks(5058));

            migrationBuilder.UpdateData(
                table: "Nominas",
                keyColumn: "Id",
                keyValue: new Guid("376d45c8-659d-4ace-b249-cfbf4f231915"),
                column: "FechaCreacion",
                value: new DateTime(2023, 9, 8, 13, 39, 49, 425, DateTimeKind.Local).AddTicks(5301));

            migrationBuilder.UpdateData(
                table: "Nominas",
                keyColumn: "Id",
                keyValue: new Guid("c9d4c053-49b6-410c-bc78-2d54a9991872"),
                column: "FechaCreacion",
                value: new DateTime(2023, 9, 8, 13, 39, 49, 425, DateTimeKind.Local).AddTicks(5297));
        }
    }
}
