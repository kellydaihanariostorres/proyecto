﻿using Contracts;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public class RepositorioNomina : RepositoryBase<Nomina>, IRepositorioNomina
    {
        public RepositorioNomina(RepositoryContext repositoryContext)
           : base(repositoryContext)
        {
        }

        public IQueryable<Nomina> GetAllNominas(bool trackChanges) =>
            FindAll(trackChanges);

        public Nomina GetNomina(Guid nominaId, bool trackChanges) =>
            FindByCondition(n => n.Id == nominaId, trackChanges)
            .SingleOrDefault();

        public void CreateNomina(Nomina nomina) =>
            Create(nomina);

    }
}
